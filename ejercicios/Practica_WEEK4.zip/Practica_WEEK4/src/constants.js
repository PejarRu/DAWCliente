'use strict'
export const SERVER = 'http://arturober.com:5007'
export const WEEKDAYS = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa']
export const TABLE = '/restaurants'
// export const LOCAL = 'http://localhost:5500';
